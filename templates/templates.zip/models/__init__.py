"""
Data models for the CONTRA application.
""" 