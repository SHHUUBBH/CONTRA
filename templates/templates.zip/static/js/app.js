// CONTRA - Main Application JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const generateForm = document.getElementById('generate-form');
    const advancedBtn = document.getElementById('advanced-btn');
    const advancedOptions = document.getElementById('advanced-options');
    const loadingSection = document.getElementById('loading');
    const resultsSection = document.getElementById('results');
    const tabLinks = document.querySelectorAll('.tab-link');
    const tabContents = document.querySelectorAll('.tab-content');
    
    // Sliders value display
    const variantsSlider = document.getElementById('variants');
    const variantsValue = document.getElementById('variants-value');
    const temperatureSlider = document.getElementById('temperature');
    const temperatureValue = document.getElementById('temperature-value');
    
    // Initialize sliders
    if (variantsSlider && variantsValue) {
        variantsSlider.addEventListener('input', function() {
            variantsValue.textContent = this.value;
        });
    }
    
    if (temperatureSlider && temperatureValue) {
        temperatureSlider.addEventListener('input', function() {
            temperatureValue.textContent = this.value;
        });
    }
    
    // Advanced options toggle
    if (advancedBtn && advancedOptions) {
        advancedBtn.addEventListener('click', function() {
            advancedOptions.classList.toggle('hidden');
            this.textContent = advancedOptions.classList.contains('hidden') 
                ? 'Advanced Options' 
                : 'Hide Advanced Options';
        });
    }
    
    // Tab switching
    if (tabLinks.length > 0) {
        tabLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Remove active class from all tabs
                tabLinks.forEach(tab => tab.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                
                // Add active class to clicked tab
                this.classList.add('active');
                
                // Show corresponding content
                const tabId = this.getAttribute('data-tab');
                document.getElementById(`${tabId}-tab`).classList.add('active');
            });
        });
    }
    
    // Form submission
    if (generateForm) {
        generateForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Show loading indicator
            loadingSection.classList.remove('hidden');
            resultsSection.classList.add('hidden');
            
            // Get form data
            const formData = new FormData(generateForm);
            const payload = {
                topic: formData.get('topic'),
                tone: formData.get('tone'),
                variants: parseInt(formData.get('variants'))
            };
            
            // Add advanced options if present
            if (!advancedOptions.classList.contains('hidden')) {
                payload.advanced = {
                    max_length: parseInt(formData.get('max_length')),
                    temperature: parseFloat(formData.get('temperature'))
                };
            }
            
            try {
                // Call API
                const response = await fetch('/api/generate', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(payload)
                });
                
                if (!response.ok) {
                    throw new Error(`API error: ${response.statusText}`);
                }
                
                const data = await response.json();
                
                if (!data.success) {
                    throw new Error(data.error || 'Unknown error occurred');
                }
                
                // Display results
                displayResults(data.result);
                
                // Hide loading, show results
                loadingSection.classList.add('hidden');
                resultsSection.classList.remove('hidden');
                
                // Scroll to results
                resultsSection.scrollIntoView({ behavior: 'smooth' });
                
            } catch (error) {
                console.error('Error:', error);
                alert(`Generation failed: ${error.message}`);
                loadingSection.classList.add('hidden');
            }
        });
    }
    
    // Function to display results
    function displayResults(result) {
        // Set topic heading
        const topicHeading = document.getElementById('topic-heading');
        if (topicHeading) {
            topicHeading.textContent = result.topic;
        }
        
        // Display narrative
        displayNarrative(result.narrative);
        
        // Display images
        displayImages(result.images);
        
        // Display visualizations
        displayVisualizations(result.visualizations);
        
        // Display data sources
        displayDataSources(result.data);
    }
    
    // Display narrative content
    function displayNarrative(narrative) {
        const bulletsContainer = document.getElementById('bullets-container');
        const narrativeText = document.getElementById('narrative-text');
        
        if (bulletsContainer && narrative.bullets) {
            bulletsContainer.innerHTML = narrative.bullets;
        }
        
        if (narrativeText && narrative.narrative) {
            // Convert plain text to paragraphs
            narrativeText.innerHTML = narrative.narrative
                .split('\n\n')
                .filter(p => p.trim().length > 0)
                .map(p => `<p>${p}</p>`)
                .join('');
        }
    }
    
    // Display generated images
    function displayImages(images) {
        const imagesContainer = document.getElementById('images-container');
        const imagePrompt = document.getElementById('image-prompt');
        
        if (imagesContainer) {
            imagesContainer.innerHTML = '';
            
            if (images && images.length > 0) {
                images.forEach((image, index) => {
                    if (image.url) {
                        const imageCard = document.createElement('div');
                        imageCard.className = 'image-card';
                        
                        imageCard.innerHTML = `
                            <img src="${image.url}" alt="Generated image ${index + 1}">
                            <div class="image-info">
                                <h4>Variant ${index + 1}</h4>
                                <p>Style: ${image.style || 'Default'}</p>
                                ${image.emotion ? `<p>Emotion: ${image.emotion}</p>` : ''}
                            </div>
                        `;
                        
                        imagesContainer.appendChild(imageCard);
                    }
                });
                
                // Display the prompt used for image generation
                if (imagePrompt && images[0] && images[0].prompt) {
                    imagePrompt.textContent = `Prompt: ${images[0].prompt}`;
                }
            } else {
                imagesContainer.innerHTML = '<p>No images were generated.</p>';
            }
        }
    }
    
    // Display data visualizations
    function displayVisualizations(visualizations) {
        if (!visualizations) return;
        
        // Timeline visualization
        if (visualizations.timeline) {
            const timelineDiv = document.getElementById('timeline-viz');
            if (timelineDiv) {
                Plotly.newPlot(timelineDiv, visualizations.timeline.data, visualizations.timeline.layout);
            }
        }
        
        // Category bar chart
        if (visualizations.category_bar) {
            const categoryDiv = document.getElementById('category-viz');
            if (categoryDiv) {
                Plotly.newPlot(categoryDiv, visualizations.category_bar.data, visualizations.category_bar.layout);
            }
        }
        
        // Concept map - Using D3.js
        if (visualizations.concept_map) {
            const conceptDiv = document.getElementById('concept-viz');
            if (conceptDiv) {
                renderConceptMap(conceptDiv, visualizations.concept_map);
            }
        }
    }
    
    // Render concept map using D3.js
    function renderConceptMap(container, data) {
        if (!data || !data.nodes || !data.links || data.nodes.length === 0) {
            container.innerHTML = '<p>No concept map data available.</p>';
            return;
        }
        
        container.innerHTML = `<h3>${data.title || 'Concept Map'}</h3>`;
        
        // Set up D3 force simulation
        const width = container.clientWidth;
        const height = 300;
        
        const svg = d3.select(container)
            .append('svg')
            .attr('width', width)
            .attr('height', height);
            
        // Add group for zoom/pan
        const g = svg.append('g');
        
        // Color scale for node groups
        const color = d3.scaleOrdinal(d3.schemeCategory10);
        
        // Create force simulation
        const simulation = d3.forceSimulation(data.nodes)
            .force('link', d3.forceLink(data.links).id(d => d.id).distance(100))
            .force('charge', d3.forceManyBody().strength(-300))
            .force('center', d3.forceCenter(width / 2, height / 2));
        
        // Draw links
        const link = g.append('g')
            .selectAll('line')
            .data(data.links)
            .enter().append('line')
            .attr('stroke', '#999')
            .attr('stroke-opacity', 0.6)
            .attr('stroke-width', d => Math.sqrt(d.value));
        
        // Draw nodes
        const node = g.append('g')
            .selectAll('circle')
            .data(data.nodes)
            .enter().append('circle')
            .attr('r', d => d.group === 1 ? 10 : 7)
            .attr('fill', d => color(d.group))
            .call(d3.drag()
                .on('start', dragstarted)
                .on('drag', dragged)
                .on('end', dragended));
        
        // Add labels
        const labels = g.append('g')
            .selectAll('text')
            .data(data.nodes)
            .enter().append('text')
            .text(d => d.id)
            .attr('font-size', d => d.group === 1 ? '12px' : '10px')
            .attr('dx', 12)
            .attr('dy', 4)
            .style('fill', '#f0f0f0');
        
        // Update positions on each tick
        simulation.on('tick', () => {
            link
                .attr('x1', d => d.source.x)
                .attr('y1', d => d.source.y)
                .attr('x2', d => d.target.x)
                .attr('y2', d => d.target.y);
            
            node
                .attr('cx', d => d.x)
                .attr('cy', d => d.y);
            
            labels
                .attr('x', d => d.x)
                .attr('y', d => d.y);
        });
        
        // Drag functions
        function dragstarted(event, d) {
            if (!event.active) simulation.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
        }
        
        function dragged(event, d) {
            d.fx = event.x;
            d.fy = event.y;
        }
        
        function dragended(event, d) {
            if (!event.active) simulation.alphaTarget(0);
            d.fx = null;
            d.fy = null;
        }
    }
    
    // Display data sources
    function displayDataSources(data) {
        if (!data) return;
        
        // Wikipedia data
        const wikipediaDiv = document.getElementById('wikipedia-data');
        if (wikipediaDiv && data.wikipedia) {
            wikipediaDiv.innerHTML = `
                <p>${data.wikipedia.summary}</p>
                ${data.wikipedia.url ? `<p><a href="${data.wikipedia.url}" target="_blank">View on Wikipedia</a></p>` : ''}
            `;
        }
        
        // News data
        const newsDiv = document.getElementById('news-data');
        if (newsDiv && data.news && data.news.length > 0) {
            newsDiv.innerHTML = `
                <ul>
                    ${data.news.map(article => `
                        <li>
                            <a href="${article.url}" target="_blank">${article.title}</a>
                            <small>${article.publisher || ''} ${article.published_at || ''}</small>
                        </li>
                    `).join('')}
                </ul>
            `;
        } else if (newsDiv) {
            newsDiv.innerHTML = '<p>No news articles found.</p>';
        }
        
        // DBpedia data
        const dbpediaDiv = document.getElementById('dbpedia-data');
        if (dbpediaDiv && data.dbpedia) {
            if (data.dbpedia.categories && data.dbpedia.categories.length > 0) {
                dbpediaDiv.innerHTML = `
                    <ul>
                        ${data.dbpedia.categories.map(category => `<li>${category}</li>`).join('')}
                    </ul>
                `;
            } else {
                dbpediaDiv.innerHTML = '<p>No categories found.</p>';
            }
        }
    }
}); 