# CONTRA - Project Structure

```
contra/
│
├── app.py                   # Main Flask application
├── config.py                # Configuration settings
│
├── core/                    # Core functionality
│   ├── __init__.py
│   ├── data_fetcher.py      # Retrieve contextual data
│   ├── image_generator.py   # Generate images via Stable Diffusion
│   ├── narrative_generator.py # Generate narratives via LLaMA
│   └── visualizer.py        # Create data visualizations
│
├── utils/                   # Utility functions
│   ├── __init__.py
│   ├── cache.py             # Caching mechanisms
│   ├── validators.py        # Input validation
│   └── helpers.py           # General helper functions
│
├── services/                # External API integrations
│   ├── __init__.py
│   ├── groq_client.py       # Groq LLaMA API client
│   ├── stable_diffusion.py  # Stable Diffusion API client
│   ├── wikipedia_service.py # Wikipedia API client
│   ├── dbpedia_service.py   # DBpedia SPARQL client
│   └── news_service.py      # News API client
│
├── models/                  # Data models
│   ├── __init__.py
│   ├── art_model.py         # Image generation model
│   ├── narrative_model.py   # Narrative generation model
│   └── data_model.py        # Input/output data models
│
├── templates/               # Flask templates
│   ├── index.html           # Main application page
│   ├── about.html           # About page
│   └── components/          # Reusable components
│       ├── header.html
│       └── footer.html
│
├── static/                  # Static assets
│   ├── css/
│   │   └── style.css        # Main stylesheet
│   ├── js/
│   │   ├── app.js           # Main application logic
│   │   ├── visualizations.js # Visualization rendering
│   │   └── utils.js         # JavaScript utilities
│   └── img/                 # Static images
│
├── tests/                   # Unit and integration tests
│   ├── __init__.py
│   ├── test_data_fetcher.py
│   ├── test_image_generator.py
│   └── test_narrative_generator.py
│
├── cache/                   # Cache directory
│   ├── images/              # Cached generated images
│   └── data/                # Cached API responses
│
├── .env.example             # Example environment variables
├── requirements.txt         # Python dependencies
└── README.md                # Project documentation
``` 