"""
External API services for the CONTRA application.
""" 