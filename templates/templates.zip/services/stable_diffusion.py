"""
Stable Diffusion API client service for image generation.
"""

import os
import logging
import requests
import hashlib
import time
import base64
import io
import textwrap
from typing import Dict, List, Any, Optional
from PIL import Image
from pathlib import Path

from config import APIConfig, IMAGE_CACHE_DIR
from utils.cache import disk_cache
from utils.helpers import sanitize_filename, iso_now

# Configure logging
logger = logging.getLogger(__name__)

class StableDiffusionClient:
    """
    Client for Stable Diffusion API through Stability AI or Gradio endpoints.
    
    This client manages:
    - Connection to hosted Stable Diffusion endpoints
    - Prompt engineering for effective image generation
    - Caching of generated images
    - Image metadata
    """
    
    def __init__(
        self, 
        endpoint_url: Optional[str] = None,
        model_version: Optional[str] = None
    ):
        """
        Initialize the Stable Diffusion client.
        
        Args:
            endpoint_url: URL for the Stable Diffusion endpoint
            model_version: Version of Stable Diffusion being used
        """
        self.endpoint = endpoint_url or APIConfig.SD_ENDPOINT
        self.model_version = model_version or APIConfig.SD_MODEL_VERSION
        self.api_key = os.getenv("STABILITY_API_KEY", "")
        self.use_custom_gradio = os.getenv("USE_CUSTOM_GRADIO", "").lower() == "true"
        
        if not self.endpoint:
            logger.warning("No Stable Diffusion endpoint URL provided. Image generation will fail.")
        
        if "stability.ai" in str(self.endpoint) and not self.api_key and not self.use_custom_gradio:
            logger.warning("Using Stability AI endpoint but no API key provided. Image generation will fail.")
            
        if self.use_custom_gradio:
            logger.info(f"Using custom Gradio endpoint for Stable Diffusion: {self.endpoint}")
    
    def _hash_prompt(self, prompt: str, **params) -> str:
        """
        Generate a consistent hash for caching based on prompt and parameters.
        
        Args:
            prompt: The image generation prompt
            **params: Additional parameters that affect generation
            
        Returns:
            A hexadecimal string hash
        """
        # Combine prompt with relevant parameters
        hashable = prompt
        if params:
            # Add relevant parameters to the hash input
            relevant_params = {
                k: v for k, v in params.items() 
                if k in ['width', 'height', 'seed', 'negative_prompt', 'style']
            }
            hashable += str(relevant_params)
            
        # Create a SHA-256 hash
        return hashlib.sha256(hashable.encode('utf-8')).hexdigest()
    
    def _cache_path(self, prompt_hash: str, variant: int = 1) -> Path:
        """
        Compute file path for a given prompt hash and variant number.
        
        Args:
            prompt_hash: Hash of the prompt and parameters
            variant: Image variant number
            
        Returns:
            Path to the cached image file
        """
        return IMAGE_CACHE_DIR / f"{prompt_hash}_v{variant}.png"
    
    def build_prompt(
        self,
        topic: str,
        context_text: str = "",
        style: str = "photorealistic",
        emotion: Optional[str] = None,
        headlines: Optional[List[str]] = None
    ) -> str:
        """
        Build a rich text prompt for Stable Diffusion.
        
        Args:
            topic: Main subject/topic
            context_text: Additional contextual information
            style: Artistic style (e.g., "oil painting", "watercolor")
            emotion: Emotional tone (e.g., "somber", "triumphant")
            headlines: List of news headlines for context
            
        Returns:
            Formatted prompt string
        """
        parts = [f"{topic}, {style}"]
        
        # Add emotion if provided
        if emotion:
            parts.append(f"evoking {emotion} emotion")
        
        # Add minimal contextual cues from context text
        if context_text:
            # Limit context to avoid word salad
            parts.append(textwrap.shorten(context_text, width=100, placeholder="..."))
        
        # Include up to 3 headlines if provided
        if headlines:
            for h in headlines[:3]:
                parts.append(f"headline: {h}")
        
        # Add quality enhancers
        parts.append("dramatic lighting, 8k resolution, detailed")
        
        # Combine into final prompt
        return ", ".join(parts)
    
    def generate_image(
        self,
        prompt: str,
        negative_prompt: str = "blurry, low quality, distorted, disfigured",
        width: int = 512,
        height: int = 512,
        num_variants: int = 1,
        seed: Optional[int] = None,
        overwrite_cache: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Generate one or more image variants for the given prompt.
        
        Args:
            prompt: Text prompt for image generation
            negative_prompt: Text to discourage in the generation
            width: Image width in pixels
            height: Image height in pixels
            num_variants: Number of image variants to generate
            seed: Random seed for reproducibility (None for random)
            overwrite_cache: Whether to overwrite cached images
            
        Returns:
            List of dictionaries with image metadata
        """
        if not self.endpoint:
            return [{
                "success": False,
                "error": "No Stable Diffusion endpoint configured"
            }]
        
        # Hash prompt and parameters for caching
        param_dict = {
            'width': width,
            'height': height,
            'negative_prompt': negative_prompt,
            'seed': seed
        }
        prompt_hash = self._hash_prompt(prompt, **param_dict)
        results = []
        
        for i in range(1, num_variants + 1):
            cache_file = self._cache_path(prompt_hash, i)
            
            # Check if cached version exists
            if cache_file.exists() and not overwrite_cache:
                logger.info(f"Loading cached image for variant {i}")
                results.append({
                    "success": True,
                    "file_path": str(cache_file),
                    "prompt": prompt,
                    "negative_prompt": negative_prompt,
                    "width": width,
                    "height": height,
                    "timestamp": iso_now(),
                    "model_version": self.model_version,
                    "source": "cache"
                })
                continue
            
            try:
                # Custom Gradio endpoint logic (from contra_stablediffusion_api.py)
                if self.use_custom_gradio:
                    logger.info(f"Generating image variant {i} with custom Gradio endpoint for prompt: {prompt[:50]}...")
                    
                    # Simplified payload for Gradio interface
                    payload = {
                        "data": [prompt]  # Gradio typically expects an array of inputs
                    }
                    
                    # Call custom Gradio endpoint
                    response = requests.post(
                        self.endpoint,
                        json=payload,
                        timeout=300  # Increase timeout for image generation (5 min)
                    )
                    
                    response.raise_for_status()
                    data = response.json()
                    
                    # Gradio typically returns {"data": [base64_image]} 
                    if "data" in data and len(data["data"]) > 0:
                        # The response could be a direct base64 string or a URL
                        if isinstance(data["data"][0], str) and data["data"][0].startswith("data:image"):
                            # Extract base64 part
                            base64_str = data["data"][0].split(",")[1]
                            image_bytes = base64.b64decode(base64_str)
                        elif isinstance(data["data"][0], str) and data["data"][0].startswith("http"):
                            # It's a URL to an image
                            img_response = requests.get(data["data"][0])
                            img_response.raise_for_status()
                            image_bytes = img_response.content
                        else:
                            logger.error(f"Unexpected Gradio response format: {data}")
                            results.append({
                                "success": False,
                                "error": "Unexpected Gradio response format",
                                "variant": i
                            })
                            continue
                    else:
                        logger.error(f"Unexpected Gradio response format: {data}")
                        results.append({
                            "success": False,
                            "error": "Unexpected Gradio response format",
                            "variant": i
                        })
                        continue
                # Stability AI API logic
                elif "stability.ai" in self.endpoint:
                    if not self.api_key:
                        logger.error("Stability AI API key is required but not provided")
                        results.append({
                            "success": False,
                            "error": "Stability AI API key is required",
                            "variant": i
                        })
                        continue
                    
                    # Setup for Stability API
                    headers = {
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json",
                        "Accept": "application/json"
                    }
                    
                    # Prepare payload for Stability API
                    payload = {
                        "text_prompts": [{"text": prompt, "weight": 1.0}],
                        "cfg_scale": 7,
                        "height": height,
                        "width": width,
                        "samples": 1,
                        "steps": 30
                    }
                    
                    # Add negative prompts if provided
                    if negative_prompt:
                        payload["text_prompts"].append({"text": negative_prompt, "weight": -1.0})
                    
                    # Add seed if provided
                    if seed is not None:
                        payload["seed"] = seed
                    
                    logger.info(f"Generating image variant {i} with Stability AI for prompt: {prompt[:50]}...")
                    response = requests.post(
                        self.endpoint,
                        headers=headers,
                        json=payload,
                        timeout=120  # 2-minute timeout
                    )
                    
                    response.raise_for_status()
                    data = response.json()
                    
                    # Check for errors
                    if "artifacts" not in data or len(data["artifacts"]) == 0:
                        error_msg = data.get("message", "Unknown error from Stability API")
                        logger.error(f"Stability API error: {error_msg}")
                        results.append({
                            "success": False,
                            "error": f"Stability API error: {error_msg}",
                            "variant": i
                        })
                        continue
                    
                    # Get the generated image
                    image_data = data["artifacts"][0]
                    image_bytes = base64.b64decode(image_data["base64"])
                    
                else:
                    # Original Gradio endpoint logic
                    payload = {
                        "prompt": prompt,
                        "negative_prompt": negative_prompt,
                        "width": width,
                        "height": height,
                        "seed": seed if seed is not None else -1  # -1 for random seed
                    }
                    
                    # Call remote API
                    logger.info(f"Generating image variant {i} for prompt: {prompt[:50]}...")
                    response = requests.post(
                        self.endpoint,
                        json=payload,
                        timeout=120  # 2-minute timeout
                    )
                    response.raise_for_status()
                    
                    # Check response format
                    if response.headers.get('content-type') == 'application/json':
                        # Handle JSON response (some endpoints return base64)
                        data = response.json()
                        
                        # Check if response contains base64-encoded image
                        if 'image' in data:
                            # Decode base64 image
                            image_bytes = base64.b64decode(data['image'])
                        else:
                            logger.error(f"Unexpected JSON response format: {data}")
                            results.append({
                                "success": False,
                                "error": "Unexpected JSON response format",
                                "variant": i
                            })
                            continue
                    else:
                        # Assume raw binary image response
                        image_bytes = response.content
                
                # Save image to cache
                with open(cache_file, 'wb') as f:
                    f.write(image_bytes)
                
                logger.info(f"Saved image variant {i} to {cache_file}")
                
                # Validate the image by trying to open it
                try:
                    img = Image.open(io.BytesIO(image_bytes))
                    # Get actual dimensions
                    actual_width, actual_height = img.size
                except Exception as e:
                    logger.error(f"Invalid image data: {e}")
                    results.append({
                        "success": False,
                        "error": f"Invalid image data: {str(e)}",
                        "variant": i
                    })
                    continue
                
                # Add to results
                results.append({
                    "success": True,
                    "file_path": str(cache_file),
                    "prompt": prompt,
                    "negative_prompt": negative_prompt,
                    "width": actual_width,
                    "height": actual_height,
                    "timestamp": iso_now(),
                    "model_version": self.model_version,
                    "source": "api"
                })
                
            except requests.exceptions.RequestException as e:
                logger.error(f"Image generation API error: {str(e)}")
                results.append({
                    "success": False,
                    "error": f"API request failed: {str(e)}",
                    "variant": i
                })
            except Exception as e:
                logger.error(f"Unexpected error during image generation: {str(e)}")
                results.append({
                    "success": False,
                    "error": f"Unexpected error: {str(e)}",
                    "variant": i
                })
        
        return results
    
    def get_styles(self) -> List[Dict[str, str]]:
        """
        Get available artistic styles for image generation.
        
        Returns:
            List of style dictionaries with name and description
        """
        return [
            {"name": "photorealistic", "description": "Highly detailed, lifelike images"},
            {"name": "oil painting", "description": "Rich, textured style reminiscent of traditional oil paintings"},
            {"name": "watercolor", "description": "Soft, flowing style with transparent colors"},
            {"name": "sketch", "description": "Black and white or colored sketch/drawing style"},
            {"name": "digital art", "description": "Clean, polished digital illustration style"},
            {"name": "comic book", "description": "Bold outlines and vibrant colors in comic style"},
            {"name": "pop art", "description": "Bright colors, bold patterns, popular culture inspired"},
            {"name": "impressionist", "description": "Emphasis on light, movement, and color over detail"},
            {"name": "surrealist", "description": "Dreamlike, fantastical imagery with unexpected elements"},
            {"name": "minimalist", "description": "Simple, clean style with limited elements"},
            {"name": "anime", "description": "Japanese animation inspired style"},
            {"name": "pixel art", "description": "Retro-style imagery composed of visible pixels"}
        ]


# Create a singleton instance
stable_diffusion_client = StableDiffusionClient() 