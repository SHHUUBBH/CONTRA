# CONTRA: Data-Driven Art Generator & Visual Storytelling Platform

CONTRA is a powerful Data-Driven Art Generator & Visual Storytelling Platform that transforms simple user prompts into immersive digital experiences by integrating:

- AI-generated art via the Stable Diffusion API
- Narrative synthesis via the Groq LLama 3.3 API
- Interactive data visualizations powered by Plotly

## 🌟 Features

- **Contextual Data Enrichment**: Automatically enriches user inputs with data from Wikipedia, DBpedia, and current news
- **AI Art Generation**: Creates high-fidelity images with customizable styles, emotions, and variations
- **Narrative Synthesis**: Produces coherent, engaging narratives with bullet points and detailed explanations
- **Interactive Visualizations**: Generates timelines, category graphs, and concept maps to visualize relationships
- **Sentiment Analysis**: Analyzes the overall sentiment around topics based on current data
- **Creative Storytelling**: Creates short stories, poems, or scripts inspired by user topics

## 🚀 Technologies

- **Backend**: Python Flask with a modular architecture
- **Data Sources**:
  - Wikipedia via wikipediaapi
  - Structured knowledge via DBpedia's SPARQL endpoint
  - News articles via GNews
- **AI Models**:
  - Text generation via Groq LLama 3.3 API (llama-3.3-70b-versatile)
  - Image generation via Stable Diffusion
- **Visualizations**: Interactive charts using Plotly
- **Frontend**: HTML, CSS, JavaScript with dark theme

## 🛠️ Project Structure

```
contra/
│
├── app.py                   # Main Flask application
├── config.py                # Configuration settings
│
├── core/                    # Core functionality
│   ├── data_fetcher.py      # Retrieve contextual data
│   ├── image_generator.py   # Generate images via Stable Diffusion
│   ├── narrative_generator.py # Generate narratives via LLaMA
│   └── visualizer.py        # Create data visualizations
│
├── utils/                   # Utility functions
│   ├── cache.py             # Caching mechanisms
│   ├── validators.py        # Input validation
│   └── helpers.py           # General helper functions
│
├── services/                # External API integrations
│   ├── groq_client.py       # Groq LLaMA API client
│   ├── stable_diffusion.py  # Stable Diffusion API client
│   ├── wikipedia_service.py # Wikipedia API client
│   ├── dbpedia_service.py   # DBpedia SPARQL client
│   └── news_service.py      # News API client
│
├── models/                  # Data models
│   └── data_model.py        # Input/output data models
│
├── templates/               # Flask templates
│   ├── index.html           # Main application page
│   └── about.html           # About page
│
├── static/                  # Static assets (CSS, JS, images)
│
├── cache/                   # Cache directory
│   ├── images/              # Cached generated images
│   └── data/                # Cached API responses
│
└── requirements.txt         # Python dependencies
```

## 📋 API Endpoints

CONTRA provides the following RESTful API endpoints:

- `POST /api/generate`: Generate content for a topic
- `GET /api/styles`: Get available image generation styles
- `GET /api/related`: Get related topics for a given topic
- `POST /api/sentiment`: Analyze sentiment for a topic
- `POST /api/story`: Generate a creative story for a topic
- `GET /api/health`: API health check
- `GET /status`: System status dashboard with API connection information

## 🔧 Setup and Installation

### Prerequisites

- Python 3.8+
- Groq API key for LLama 3.3
- Stable Diffusion API endpoint (e.g., hosted on Google Colab)
- GNews API key (for enhanced news article retrieval)

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/contra.git
   cd contra
   ```

2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Create a `.env` file with your API keys:
   ```
   GROQ_API_KEY=your_groq_api_key
   SD_GRADIO_ENDPOINT=your_stable_diffusion_endpoint
   NEWS_API_KEY=your_gnews_api_key
   FLASK_ENV=development
   ```

5. Run the application:
   ```bash
   python run.py
   ```

6. Visit `http://localhost:5000` in your browser.
   
7. Check API status at `http://localhost:5000/status`

## 🚢 Deployment

For production deployment:

1. Set environment variables properly
2. Use Gunicorn for production:
   ```bash
   gunicorn -w 4 -b 0.0.0.0:5000 'app:create_app()'
   ```

## 📝 Usage Examples

### Generate Content

```bash
curl -X POST http://localhost:5000/api/generate \
  -H "Content-Type: application/json" \
  -d '{
    "topic": "French Revolution", 
    "tone": "dramatic", 
    "style": "oil painting", 
    "variants": 2
  }'
```

### Generate Creative Story

```bash
curl -X POST http://localhost:5000/api/story \
  -H "Content-Type: application/json" \
  -d '{
    "topic": "Space Exploration", 
    "style": "short story", 
    "genre": "science fiction"
  }'
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details. 