"""
Core functionality for the CONTRA application.
""" 