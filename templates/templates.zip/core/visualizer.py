"""
Visualizer for creating interactive data visualizations.
"""

import logging
import json
import time
import re
from typing import Dict, List, Any, Optional, Tuple

import plotly.graph_objects as go
import plotly.express as px
from plotly.utils import PlotlyJSONEncoder

from models.data_model import TopicData, Visualization
from config import ContentConfig
from utils.helpers import format_time_elapsed, extract_dates_from_text

# Configure logging
logger = logging.getLogger(__name__)

class Visualizer:
    """
    Creates interactive visualizations of topic data using Plotly.
    """
    
    def __init__(self):
        """Initialize the visualizer."""
        self.theme = ContentConfig.DEFAULT_VIZ_THEME
    
    def create_visualizations(self, topic_data: TopicData) -> Dict[str, Any]:
        """
        Create a set of visualizations based on topic data.
        
        Args:
            topic_data: Normalized topic data
            
        Returns:
            Dictionary with visualization data and metadata
        """
        start_time = time.time()
        logger.info(f"Creating visualizations for topic: {topic_data.topic}")
        
        # Create individual visualizations
        timeline = self.create_timeline(topic_data)
        category_bar = self.create_category_bar(topic_data)
        concept_map = self.create_concept_map(topic_data)
        
        # Create visualization model
        visualizations = Visualization(
            timeline=timeline,
            category_bar=category_bar,
            concept_map=concept_map
        )
        
        # Return the result
        elapsed_time = time.time() - start_time
        return {
            "success": True,
            "visualizations": visualizations.to_dict(),
            "processing_time": format_time_elapsed(elapsed_time)
        }
    
    def create_timeline(self, topic_data: TopicData) -> Optional[Dict[str, Any]]:
        """
        Create a timeline visualization from news dates or extracted years.
        
        Args:
            topic_data: Normalized topic data
            
        Returns:
            Plotly JSON figure for timeline chart
        """
        events = []
        
        # Method 1: Extract dates from news articles
        for article in topic_data.news:
            if article.published_at:
                date_parts = article.published_at.split("T")[0].split("-")
                if len(date_parts) >= 3:
                    year = int(date_parts[0])
                    events.append({
                        "year": year,
                        "event": article.title,
                        "source": "news"
                    })
        
        # Method 2: Extract years from Wikipedia text
        if topic_data.wikipedia.summary:
            dates_from_text = extract_dates_from_text(topic_data.wikipedia.summary)
            for date in dates_from_text:
                events.append({
                    "year": date["year"],
                    "event": date["event"],
                    "source": "wikipedia"
                })
        
        # Method 3: Extract years from DBpedia abstract
        if topic_data.dbpedia.abstract:
            dates_from_dbpedia = extract_dates_from_text(topic_data.dbpedia.abstract)
            for date in dates_from_dbpedia:
                events.append({
                    "year": date["year"],
                    "event": date["event"],
                    "source": "dbpedia"
                })
        
        # If we have enough events, create the visualization
        if len(events) >= 2:
            # Sort by year
            events = sorted(events, key=lambda e: e["year"])
            
            # Limit to a reasonable number
            max_events = ContentConfig.TIMELINE_MAX_EVENTS
            if len(events) > max_events:
                events = events[:max_events]
            
            # Extract data for plotting
            years = [e["year"] for e in events]
            labels = [e["event"] for e in events]
            sources = [e["source"] for e in events]
            
            # Create color map for sources
            source_colors = {
                "news": "cyan",
                "wikipedia": "yellow",
                "dbpedia": "magenta"
            }
            colors = [source_colors.get(s, "gray") for s in sources]
            
            # Create the figure
            fig = go.Figure()
            
            # Add the main timeline
            fig.add_trace(
                go.Scatter(
                    x=years,
                    y=[1] * len(years),  # Single line timeline
                    mode="markers+lines",
                    marker=dict(
                        size=12,
                        color=colors,
                        line=dict(width=2, color="DarkSlateGrey")
                    ),
                    line=dict(color="gray", dash="dash"),
                    text=labels,
                    hovertemplate="<b>%{text}</b><br>Year: %{x}<extra></extra>"
                )
            )
            
            # Set layout options
            fig.update_layout(
                title=f"Timeline: {topic_data.topic}",
                xaxis=dict(
                    title="Year",
                    showgrid=True,
                    zeroline=False,
                    dtick=5  # Show tick marks every 5 years
                ),
                yaxis=dict(
                    visible=False  # Hide the y-axis
                ),
                margin=dict(l=20, r=20, t=30, b=20),
                showlegend=False,
                template=self.theme,
                height=250,  # Smaller height for the timeline
                plot_bgcolor="rgba(0,0,0,0)"  # Transparent background
            )
            
            # Convert to JSON and return
            return json.loads(json.dumps(fig, cls=PlotlyJSONEncoder))
        
        return None
    
    def create_category_bar(self, topic_data: TopicData) -> Optional[Dict[str, Any]]:
        """
        Create a bar chart of categories from DBpedia.
        
        Args:
            topic_data: Normalized topic data
            
        Returns:
            Plotly JSON figure for bar chart
        """
        if not topic_data.dbpedia.categories or len(topic_data.dbpedia.categories) < 2:
            return None
        
        # Count occurrences if there are duplicates
        category_counts = {}
        for cat in topic_data.dbpedia.categories:
            # Clean up category names (remove prefix/unwanted text)
            clean_cat = re.sub(r'^Category:', '', cat)
            # Split into words and capitalize each
            clean_cat = ' '.join(word.capitalize() for word in clean_cat.split('_'))
            
            category_counts[clean_cat] = category_counts.get(clean_cat, 0) + 1
        
        # Sort by count (descending)
        sorted_categories = sorted(
            category_counts.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        # Limit to top 10 categories
        if len(sorted_categories) > 10:
            sorted_categories = sorted_categories[:10]
        
        # Extract data for plotting
        category_names = [cat for cat, _ in sorted_categories]
        category_values = [count for _, count in sorted_categories]
        
        # Create the figure
        fig = go.Figure(
            go.Bar(
                x=category_names,
                y=category_values,
                marker_color="purple",
                hovertemplate="<b>%{x}</b><br>Count: %{y}<extra></extra>"
            )
        )
        
        # Set layout options
        fig.update_layout(
            title=f"Categories: {topic_data.topic}",
            xaxis=dict(
                title="Category",
                tickangle=45,  # Angle labels for better readability
                tickfont=dict(size=10)
            ),
            yaxis=dict(
                title="Count"
            ),
            margin=dict(l=20, r=20, t=30, b=100),  # Extra bottom margin for angled labels
            template=self.theme,
            plot_bgcolor="rgba(0,0,0,0)"  # Transparent background
        )
        
        # Convert to JSON and return
        return json.loads(json.dumps(fig, cls=PlotlyJSONEncoder))
    
    def create_concept_map(self, topic_data: TopicData) -> Optional[Dict[str, Any]]:
        """
        Create a concept map (network graph) visualization.
        
        Args:
            topic_data: Normalized topic data
            
        Returns:
            Data for D3.js or Plotly network visualization
        """
        # Need DBpedia categories or Wikipedia data to create a concept map
        if (not topic_data.dbpedia.categories and not topic_data.wikipedia.summary) or not topic_data.topic:
            return None
        
        # Create nodes and links
        nodes = [{"id": topic_data.topic, "group": 1}]
        links = []
        
        # Add categories as nodes
        for idx, category in enumerate(topic_data.dbpedia.categories[:8]):
            # Clean up category name
            clean_cat = re.sub(r'^Category:', '', category)
            clean_cat = ' '.join(word.capitalize() for word in clean_cat.split('_'))
            
            # Add as node
            nodes.append({"id": clean_cat, "group": 2})
            
            # Add link to main topic
            links.append({
                "source": topic_data.topic,
                "target": clean_cat,
                "value": 1
            })
        
        # If we have news articles, add top headlines
        for idx, article in enumerate(topic_data.news[:5]):
            if article.title:
                # Truncate title if too long
                short_title = article.title[:30] + "..." if len(article.title) > 30 else article.title
                
                # Add as node
                nodes.append({"id": short_title, "group": 3})
                
                # Add link to main topic
                links.append({
                    "source": topic_data.topic,
                    "target": short_title,
                    "value": 1
                })
        
        # Add interconnections between some nodes (for a more interesting graph)
        if len(nodes) >= 5:
            # Add some random connections
            import random
            secondary_nodes = [n["id"] for n in nodes[1:]]
            
            # Add up to 3 additional connections
            for _ in range(min(3, len(secondary_nodes) // 2)):
                choices = random.sample(secondary_nodes, 2)
                links.append({
                    "source": choices[0],
                    "target": choices[1],
                    "value": 0.5  # Weaker connection
                })
        
        return {
            "title": f"Concept Map: {topic_data.topic}",
            "nodes": nodes,
            "links": links
        }
    
    def create_sentiment_chart(self, sentiment_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Create a sentiment visualization from sentiment analysis data.
        
        Args:
            sentiment_data: Sentiment analysis data
            
        Returns:
            Plotly JSON figure for sentiment chart
        """
        if not sentiment_data or "sentiment" not in sentiment_data:
            return None
        
        # Extract sentiment value
        sentiment = sentiment_data["sentiment"].lower()
        confidence = sentiment_data.get("confidence", 0.5)
        
        # Map sentiment to numeric value
        sentiment_value = {
            "positive": 1,
            "neutral": 0,
            "negative": -1
        }.get(sentiment, 0)
        
        # Adjusted value based on confidence
        adjusted_value = sentiment_value * confidence
        
        # Create a gauge chart
        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=adjusted_value,
            domain={"x": [0, 1], "y": [0, 1]},
            title={"text": "Sentiment Analysis"},
            gauge={
                "axis": {"range": [-1, 1]},
                "bar": {"color": "darkblue"},
                "steps": [
                    {"range": [-1, -0.3], "color": "firebrick"},
                    {"range": [-0.3, 0.3], "color": "gray"},
                    {"range": [0.3, 1], "color": "forestgreen"}
                ],
                "threshold": {
                    "line": {"color": "red", "width": 4},
                    "thickness": 0.75,
                    "value": adjusted_value
                }
            }
        ))
        
        # Set layout options
        fig.update_layout(
            height=300,
            margin=dict(l=20, r=20, t=50, b=20),
            template=self.theme
        )
        
        # Convert to JSON and return
        return json.loads(json.dumps(fig, cls=PlotlyJSONEncoder))


# Create a singleton instance
visualizer = Visualizer() 