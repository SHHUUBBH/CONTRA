"""
Narrative generator for creating text narratives using the Groq LLaMA API.
"""

import logging
import time
import textwrap
from typing import Dict, List, Any, Optional

from models.data_model import Narrative, TopicData
from services.groq_client import groq_client
from config import ContentConfig
from utils.helpers import format_time_elapsed, clean_text, truncate_text

# Configure logging
logger = logging.getLogger(__name__)

class NarrativeGenerator:
    """
    Generates narratives and structured text content using LLaMA.
    """
    
    def __init__(self):
        """Initialize the narrative generator."""
        # GroqClient is initialized as a singleton in its module
        pass
    
    def generate_narrative(
        self,
        topic_data: TopicData,
        tone: str = None,
        max_tokens: int = None,
        temperature: float = None
    ) -> Dict[str, Any]:
        """
        Generate a narrative about a topic using available data.
        
        Args:
            topic_data: Normalized topic data from various sources
            tone: Narrative tone (e.g., "informative", "dramatic")
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0.0-1.0)
            
        Returns:
            Dictionary with generated narrative and metadata
        """
        start_time = time.time()
        
        # Use defaults from config if not specified
        tone = tone or ContentConfig.DEFAULT_TONE
        max_tokens = max_tokens or ContentConfig.DEFAULT_MAX_LENGTH
        temperature = temperature or ContentConfig.DEFAULT_TEMPERATURE
        
        logger.info(f"Generating narrative for topic: {topic_data.topic} (tone={tone})")
        
        # Build the prompt for LLaMA
        prompt = self._build_prompt(topic_data, tone)
        
        # Call the LLaMA API via Groq
        result = groq_client.generate_text(
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=temperature
        )
        
        if not result.get("success", False):
            elapsed_time = time.time() - start_time
            return {
                "success": False,
                "error": result.get("error", "Unknown error generating narrative"),
                "processing_time": format_time_elapsed(elapsed_time)
            }
        
        # Extract the generated text
        generated_text = result.get("text", "")
        
        # Split into bullets and narrative sections
        bullets, narrative = groq_client.extract_bullet_points(generated_text)
        
        # Create the Narrative model
        narrative_model = Narrative(
            bullets=bullets,
            narrative=narrative,
            prompt=prompt,
            model=result.get("model", "")
        )
        
        # Return the result
        elapsed_time = time.time() - start_time
        return {
            "success": True,
            "narrative": narrative_model.to_dict(),
            "processing_time": format_time_elapsed(elapsed_time)
        }
    
    def _build_prompt(self, topic_data: TopicData, tone: str) -> str:
        """
        Build a prompt for the LLaMA model that includes context from all data sources.
        
        Args:
            topic_data: Normalized topic data
            tone: Narrative tone
            
        Returns:
            Formatted prompt string
        """
        parts = []
        
        # Instructions with tone
        parts.append(f"Write a {tone} narrative about '{topic_data.topic}'.")
        parts.append("Use the following context:")
        
        # Wikipedia content
        if topic_data.wikipedia.summary:
            parts.append("\nWIKIPEDIA SUMMARY:")
            parts.append(textwrap.fill(topic_data.wikipedia.summary, width=80))
            if topic_data.wikipedia.url:
                parts.append(f"URL: {topic_data.wikipedia.url}")
        
        # DBpedia content
        if topic_data.dbpedia.abstract:
            parts.append("\nDBPEDIA ABSTRACT:")
            parts.append(textwrap.fill(topic_data.dbpedia.abstract, width=80))
        
        if topic_data.dbpedia.categories:
            parts.append("\nDBPEDIA CATEGORIES: " + ", ".join(topic_data.dbpedia.categories[:10]))
        
        # News headlines
        if topic_data.news:
            parts.append("\nRECENT NEWS HEADLINES:")
            for i, article in enumerate(topic_data.news[:5], 1):
                if article.title:
                    parts.append(f"{i}. {article.title}")
                if article.description and i <= 3:  # Include descriptions for top 3 articles
                    parts.append(f"   {truncate_text(article.description, 100)}")
        
        # Output format instructions
        parts.append(
            "\nPlease produce:\n"
            "1. A concise bullet-point summary (3–5 points).\n"
            "2. A detailed narrative in 2–4 paragraphs."
        )
        
        return "\n".join(parts)
    
    def generate_creative_story(
        self,
        topic_data: TopicData,
        style: str = "short story",
        genre: Optional[str] = None,
        max_tokens: int = None
    ) -> Dict[str, Any]:
        """
        Generate a creative story based on the topic data.
        
        Args:
            topic_data: Normalized topic data
            style: Story style (e.g., "short story", "poem", "script")
            genre: Optional genre (e.g., "mystery", "science fiction")
            max_tokens: Maximum tokens to generate
            
        Returns:
            Dictionary with generated story and metadata
        """
        start_time = time.time()
        max_tokens = max_tokens or ContentConfig.DEFAULT_MAX_LENGTH
        
        # Set a creative temperature
        temperature = 0.8
        
        # Build creative prompt
        genre_str = f" in the {genre} genre" if genre else ""
        prompt = f"Write a creative {style}{genre_str} inspired by '{topic_data.topic}'.\n\n"
        
        # Add context
        if topic_data.wikipedia.summary:
            prompt += f"Context: {truncate_text(topic_data.wikipedia.summary, 200)}\n\n"
        
        # Add specific instructions for the story style
        if style == "short story":
            prompt += "Write an engaging short story with a clear beginning, middle, and end.\n"
        elif style == "poem":
            prompt += "Write a poem with vivid imagery and metaphors.\n"
        elif style == "script":
            prompt += "Write a brief script with dialog between characters.\n"
        
        # Call the LLaMA API
        result = groq_client.generate_text(
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=temperature
        )
        
        if not result.get("success", False):
            elapsed_time = time.time() - start_time
            return {
                "success": False,
                "error": result.get("error", "Unknown error generating story"),
                "processing_time": format_time_elapsed(elapsed_time)
            }
        
        elapsed_time = time.time() - start_time
        return {
            "success": True,
            "story": result.get("text", ""),
            "style": style,
            "genre": genre,
            "model": result.get("model", ""),
            "processing_time": format_time_elapsed(elapsed_time)
        }
    
    def analyze_sentiment(self, topic_data: TopicData) -> Dict[str, Any]:
        """
        Analyze the sentiment around a topic based on available data.
        
        Args:
            topic_data: Normalized topic data
            
        Returns:
            Dictionary with sentiment analysis
        """
        # Create a structured output format for LLaMA
        output_format = {
            "sentiment": "string (positive, negative, or neutral)",
            "confidence": "number (0.0-1.0)",
            "analysis": "string (brief explanation)",
            "highlights": ["array of key points supporting the sentiment"]
        }
        
        # Build the prompt
        prompt = f"Analyze the sentiment around the topic '{topic_data.topic}' based on the following data:\n\n"
        
        # Add news headlines
        if topic_data.news:
            prompt += "NEWS HEADLINES:\n"
            for article in topic_data.news[:5]:
                prompt += f"- {article.title}\n"
        
        # Add Wikipedia context if available
        if topic_data.wikipedia.summary:
            prompt += f"\nWIKIPEDIA CONTEXT:\n{truncate_text(topic_data.wikipedia.summary, 200)}\n"
        
        # Add instruction
        prompt += "\nBased on this information, analyze the overall sentiment around this topic. " \
                 "Is it mostly positive, negative, or neutral? Provide a brief explanation and key points."
        
        # Get structured output
        result = groq_client.parse_structured_output(prompt, output_format)
        
        if not result.get("success", False):
            return {
                "success": False,
                "error": result.get("error", "Unknown error analyzing sentiment")
            }
        
        return {
            "success": True,
            "sentiment_analysis": result.get("data", {})
        }


# Create a singleton instance
narrative_generator = NarrativeGenerator() 