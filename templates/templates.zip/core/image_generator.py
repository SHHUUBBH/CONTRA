"""
Image generator for creating images using Stable Diffusion.
"""

import logging
import time
import re
from typing import Dict, List, Any, Optional, Tuple

from models.data_model import TopicData, Image
from services.stable_diffusion import stable_diffusion_client
from config import ContentConfig
from utils.helpers import format_time_elapsed, truncate_text

# Configure logging
logger = logging.getLogger(__name__)

class ImageGenerator:
    """
    Generates images using Stable Diffusion based on topic data.
    """
    
    def __init__(self):
        """Initialize the image generator."""
        # StableDiffusionClient is initialized as a singleton in its module
        pass
    
    def generate_images(
        self,
        topic_data: TopicData,
        narrative_text: Optional[str] = None,
        num_variants: int = None,
        width: int = None,
        height: int = None
    ) -> Dict[str, Any]:
        """
        Generate images for a topic using available data.
        Automatically determines appropriate style and emotion based on the topic and context.
        
        Args:
            topic_data: Normalized topic data
            narrative_text: Optional narrative text to include in prompt
            num_variants: Number of image variants to generate
            width: Image width in pixels
            height: Image height in pixels
            
        Returns:
            Dictionary with generated images and metadata
        """
        start_time = time.time()
        
        # Use defaults from config if not specified
        num_variants = num_variants or ContentConfig.DEFAULT_NUM_VARIANTS
        width = width or ContentConfig.DEFAULT_IMAGE_WIDTH
        height = height or ContentConfig.DEFAULT_IMAGE_HEIGHT
        
        # Build context text from Wikipedia and/or DBpedia
        context_text = ""
        if topic_data.wikipedia.summary:
            context_text = topic_data.wikipedia.summary
        elif topic_data.dbpedia.abstract:
            context_text = topic_data.dbpedia.abstract
        
        # Include narrative text if provided (it might have better context)
        if narrative_text:
            context_text = narrative_text
        
        # Automatically determine style and emotion based on the topic and context
        style, emotion = self._analyze_topic_for_style_and_emotion(topic_data.topic, context_text)
        
        logger.info(f"Generating images for topic: {topic_data.topic} (style={style}, emotion={emotion}, variants={num_variants})")
        
        # Get news headlines
        headlines = []
        for article in topic_data.news[:3]:
            if article.title:
                headlines.append(article.title)
        
        # Build the prompt
        prompt = stable_diffusion_client.build_prompt(
            topic=topic_data.topic,
            context_text=context_text,
            style=style,
            emotion=emotion,
            headlines=headlines
        )
        
        # Generate images
        result = stable_diffusion_client.generate_image(
            prompt=prompt,
            width=width,
            height=height,
            num_variants=num_variants
        )
        
        if not result or any(not r.get("success", False) for r in result):
            # If any image generation failed
            elapsed_time = time.time() - start_time
            return {
                "success": False,
                "error": "Failed to generate one or more images",
                "partial_results": result,
                "processing_time": format_time_elapsed(elapsed_time)
            }
        
        # Create image models
        images = []
        for img_data in result:
            if img_data.get("success", False):
                images.append(Image(
                    file_path=img_data.get("file_path", ""),
                    prompt=img_data.get("prompt", ""),
                    model_version=img_data.get("model_version", ""),
                    timestamp=img_data.get("timestamp", ""),
                    style=style,
                    width=img_data.get("width", width),
                    height=img_data.get("height", height)
                ))
        
        # Return the result
        elapsed_time = time.time() - start_time
        return {
            "success": True,
            "images": [img.to_dict() for img in images],
            "prompt": prompt,
            "style": style,
            "emotion": emotion,
            "processing_time": format_time_elapsed(elapsed_time)
        }
    
    def _analyze_topic_for_style_and_emotion(self, topic: str, context_text: str) -> Tuple[str, Optional[str]]:
        """
        Analyze the topic and context to determine the most appropriate art style and emotion.
        
        Args:
            topic: The main topic
            context_text: Additional context information
            
        Returns:
            Tuple of (style, emotion)
        """
        # Use LLaMA if available, otherwise use rule-based approach
        try:
            from services.groq_client import groq_client
            
            # Try to use LLaMA for more intelligent analysis
            if groq_client.api_key:
                return self._analyze_with_llama(topic, context_text)
        except Exception as e:
            logger.warning(f"Could not use LLaMA for style analysis: {e}")
        
        # Fallback to rule-based approach
        return self._analyze_with_rules(topic, context_text)
    
    def _analyze_with_llama(self, topic: str, context_text: str) -> Tuple[str, Optional[str]]:
        """Use LLaMA to determine style and emotion."""
        from services.groq_client import groq_client
        
        prompt = f"""
        Analyze the following topic and context, and determine the most appropriate art style and emotion for a visual representation.
        
        Topic: "{topic}"
        
        Context: {truncate_text(context_text, 300)}
        
        Available art styles: photorealistic, oil painting, watercolor, sketch, digital art, comic book, pop art, impressionist, surrealist, minimalist, anime, pixel art
        
        Available emotions: joyful, sad, angry, fearful, mysterious, romantic, hopeful, nostalgic, none
        
        Respond in JSON format:
        {{
            "style": "chosen_style",
            "emotion": "chosen_emotion",
            "reason": "brief explanation"
        }}
        """
        
        result = groq_client.parse_structured_output(
            prompt=prompt,
            output_format={"style": "", "emotion": "", "reason": ""}
        )
        
        if result.get("success", False) and "data" in result:
            data = result["data"]
            style = data.get("style", "photorealistic")
            emotion = data.get("emotion")
            
            # Validate style is in our allowed list
            valid_styles = set([s["name"] for s in stable_diffusion_client.get_styles()])
            if style not in valid_styles:
                style = "photorealistic"
                
            # Set emotion to None if "none" is selected
            if emotion == "none":
                emotion = None
                
            logger.info(f"LLaMA analysis: Style={style}, Emotion={emotion}, Reason={data.get('reason')}")
            return style, emotion
            
        # Fallback to rule-based approach
        return self._analyze_with_rules(topic, context_text)
    
    def _analyze_with_rules(self, topic: str, context_text: str) -> Tuple[str, Optional[str]]:
        """
        Use rule-based approach to determine style and emotion.
        Maps topic keywords to styles and emotions.
        """
        # Combine topic and context for analysis
        combined_text = f"{topic} {context_text}".lower()
        
        # Style mapping based on keywords
        style_keywords = {
            "photorealistic": ["realistic", "photograph", "modern", "contemporary", "today", "current"],
            "oil painting": ["classical", "renaissance", "baroque", "traditional", "portrait", "historical"],
            "watercolor": ["nature", "landscape", "gentle", "soft", "delicate", "flower", "garden"],
            "sketch": ["drawing", "concept", "quick", "simple", "line", "draft"],
            "digital art": ["computer", "technology", "future", "sci-fi", "science fiction", "tech", "digital"],
            "comic book": ["superhero", "action", "adventure", "character", "hero", "villain"],
            "pop art": ["colorful", "vibrant", "bold", "1960", "warhol", "advertisement", "celebrity"],
            "impressionist": ["light", "color", "outdoor", "scene", "19th century", "monet"],
            "surrealist": ["dream", "strange", "bizarre", "subconscious", "symbolic", "dali", "abstract"],
            "minimalist": ["simple", "clean", "modern", "minimal", "geometric", "basic"],
            "anime": ["japan", "manga", "cartoon", "character", "animation"],
            "pixel art": ["game", "retro", "8-bit", "video game", "arcade", "nintendo"]
        }
        
        # Emotion mapping based on keywords
        emotion_keywords = {
            "joyful": ["happy", "joy", "celebration", "success", "victory", "achievement", "festival"],
            "sad": ["sad", "sorrow", "grief", "tragic", "loss", "depression", "melancholy", "defeat"],
            "angry": ["anger", "rage", "fury", "war", "battle", "conflict", "fight", "rebellion", "protest"],
            "fearful": ["fear", "terror", "horror", "scary", "danger", "threat", "monster", "disaster"],
            "mysterious": ["mystery", "secret", "unknown", "enigma", "hidden", "question", "curious"],
            "romantic": ["love", "romance", "relationship", "passion", "couple", "marriage", "date"],
            "hopeful": ["hope", "future", "optimism", "new", "beginning", "dawn", "progress"],
            "nostalgic": ["nostalgia", "past", "memory", "childhood", "history", "vintage", "retro", "remember"]
        }
        
        # Historical periods suggest certain styles
        historical_periods = {
            r"prehistoric|stone age|cave": "sketch",
            r"ancient|egypt|greek|roman": "oil painting",
            r"medieval|middle ages|renaissance": "oil painting",
            r"19th century": "impressionist",
            r"1920s|1930s|1940s": "pop art",
            r"1950s|1960s|1970s": "pop art",
            r"future|21st century|modern": "digital art"
        }
        
        # Score each style and emotion based on keyword matches
        style_scores = {style: 0 for style in style_keywords}
        emotion_scores = {emotion: 0 for emotion in emotion_keywords}
        
        # Check for historical period matches
        for pattern, style in historical_periods.items():
            if re.search(pattern, combined_text):
                style_scores[style] += 5  # Strong boost for historical match
        
        # Check for keyword matches
        for style, keywords in style_keywords.items():
            for keyword in keywords:
                if keyword in combined_text:
                    style_scores[style] += 1
        
        for emotion, keywords in emotion_keywords.items():
            for keyword in keywords:
                if keyword in combined_text:
                    emotion_scores[emotion] += 1
        
        # Get the highest scoring style and emotion
        selected_style = max(style_scores.items(), key=lambda x: x[1])[0]
        if style_scores[selected_style] == 0:
            selected_style = "photorealistic"  # Default if no matches
            
        # For emotion, only select if there's a clear signal
        selected_emotion = max(emotion_scores.items(), key=lambda x: x[1])[0]
        if emotion_scores[selected_emotion] < 2:  # Require at least 2 matches for emotion
            selected_emotion = None
            
        logger.info(f"Rule-based analysis: Style={selected_style}, Emotion={selected_emotion}")
        return selected_style, selected_emotion
    
    def enhance_image_prompt(self, topic: str, context_text: str) -> str:
        """
        Enhance an image generation prompt with additional details.
        
        Uses the LLaMA model to expand a simple topic into a detailed
        image generation prompt.
        
        Args:
            topic: Topic string
            context_text: Additional context text
            
        Returns:
            Enhanced prompt string
        """
        from services.groq_client import groq_client
        
        # Create prompt for LLaMA
        llama_prompt = f"""
        Create a detailed Stable Diffusion prompt for an image about "{topic}".
        
        Context information: {truncate_text(context_text, 300)}
        
        Your prompt should:
        1. Include specific visual details that would make an interesting image
        2. Specify style, lighting, mood, and composition
        3. Be formatted as a comma-separated list of descriptors
        4. Be around 40-60 words in length
        
        Stable Diffusion Prompt:
        """
        
        # Generate enhanced prompt
        result = groq_client.generate_text(
            prompt=llama_prompt,
            max_tokens=100,
            temperature=0.7
        )
        
        if not result.get("success", False):
            # If generation failed, return a basic prompt
            return f"{topic}, detailed, high quality"
        
        return result.get("text", "").strip()
    
    def get_available_styles(self) -> List[Dict[str, str]]:
        """
        Get available artistic styles for image generation.
        
        Returns:
            List of style dictionaries with name and description
        """
        return stable_diffusion_client.get_styles()


# Create a singleton instance
image_generator = ImageGenerator() 