"""
Main Flask application for the CONTRA Data-Driven Art Generator & Visual Storytelling Platform.
"""

import os
import logging
import time
from flask import Flask, Blueprint, request, jsonify, render_template, send_from_directory, abort
from werkzeug.exceptions import HTTPException

from config import FlaskConfig
from models.data_model import GenerationResult
from core.data_fetcher import data_fetcher
from core.narrative_generator import narrative_generator
from core.image_generator import image_generator
from core.visualizer import visualizer
from utils.validators import validate_input
from utils.helpers import format_time_elapsed
from utils.api_status import get_all_api_statuses

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create API blueprint
api_bp = Blueprint('api', __name__, url_prefix='/api')

# Create static file blueprint for serving generated images
images_bp = Blueprint('images', __name__, url_prefix='/images')

@images_bp.route('/<path:filename>')
def serve_image(filename):
    """Serve generated images from cache directory."""
    from config import IMAGE_CACHE_DIR
    try:
        return send_from_directory(IMAGE_CACHE_DIR, filename)
    except Exception:
        abort(404)

@api_bp.route('/generate', methods=['POST'])
def generate():
    """
    Generate content for a topic.
    
    POST /api/generate
    Request JSON: {
        "topic": "string",
        "tone": "string" (optional),
        "variants": int (optional),
        "advanced": {
            "max_length": int (optional),
            "temperature": float (optional)
        }
    }
    
    Returns:
        JSON response with generated content
    """
    start_time = time.time()
    
    # Get JSON request data
    data = request.get_json(silent=True)
    if not data:
        return jsonify({
            "success": False,
            "error": "Missing request body or invalid JSON"
        }), 400
    
    # Validate input
    valid, error_message, normalized = validate_input(data)
    if not valid:
        return jsonify({
            "success": False,
            "error": error_message
        }), 400
    
    # Extract parameters
    topic = normalized['topic']
    tone = normalized.get('tone', 'informative')
    variants = normalized.get('variants', 1)
    
    # Advanced parameters
    advanced = normalized.get('advanced', {})
    max_length = advanced.get('max_length')
    temperature = advanced.get('temperature')
    
    try:
        logger.info(f"Starting generation for topic: {topic}")
        
        # 1. Fetch data
        logger.info("Step 1: Fetching data...")
        data_result = data_fetcher.fetch_topic_data(topic)
        
        if not data_result.get('success', False):
            return jsonify({
                "success": False,
                "error": "Failed to fetch topic data",
                "details": data_result.get('errors')
            }), 500
        
        # Create a topic data model from the result
        from models.data_model import TopicData
        topic_data = TopicData(
            topic=topic,
            wikipedia=data_result['data']['wikipedia'],
            dbpedia=data_result['data']['dbpedia'],
            news=data_result['data']['news']
        )
        
        # 2. Generate narrative
        logger.info("Step 2: Generating narrative...")
        narrative_result = narrative_generator.generate_narrative(
            topic_data=topic_data,
            tone=tone,
            max_tokens=max_length,
            temperature=temperature
        )
        
        if not narrative_result.get('success', False):
            return jsonify({
                "success": False,
                "error": "Failed to generate narrative",
                "details": narrative_result.get('error')
            }), 500
        
        # 3. Generate images
        logger.info("Step 3: Generating images...")
        narrative_text = narrative_result['narrative']['narrative']
        
        image_result = image_generator.generate_images(
            topic_data=topic_data,
            narrative_text=narrative_text,
            num_variants=variants
        )
        
        # Continue even if image generation fails (partial result)
        image_success = image_result.get('success', False)
        
        # 4. Create visualizations
        logger.info("Step 4: Creating visualizations...")
        viz_result = visualizer.create_visualizations(topic_data)
        
        # 5. Compile response
        elapsed_time = time.time() - start_time
        
        # Create the complete result
        result = GenerationResult(
            topic=topic,
            data=topic_data,
            narrative=narrative_result['narrative'],
            images=[],
            processing_time=format_time_elapsed(elapsed_time)
        )
        
        # Add images if successful
        if image_success and 'images' in image_result:
            # Set images URLs relative to server
            images = []
            for img in image_result['images']:
                if 'file_path' in img:
                    # Extract just the filename from the path
                    from pathlib import Path
                    filename = Path(img['file_path']).name
                    img['url'] = f"/images/{filename}"
                images.append(img)
            result.images = images
        
        # Add visualizations if available
        if viz_result.get('success', False) and 'visualizations' in viz_result:
            result.visualizations = viz_result['visualizations']
        
        # Return the full result
        return jsonify({
            "success": True,
            "result": result.to_dict()
        })
        
    except Exception as e:
        logger.exception(f"Unexpected error: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Server error",
            "details": str(e)
        }), 500


@api_bp.route('/styles', methods=['GET'])
def get_styles():
    """Get available image generation styles."""
    styles = image_generator.get_available_styles()
    return jsonify({
        "success": True,
        "styles": styles
    })


@api_bp.route('/related', methods=['GET'])
def get_related_topics():
    """Get related topics for a given topic."""
    topic = request.args.get('topic')
    if not topic:
        return jsonify({
            "success": False,
            "error": "Missing 'topic' parameter"
        }), 400
    
    # Validate topic
    valid, error = validate_topic(topic)
    if not valid:
        return jsonify({
            "success": False,
            "error": error
        }), 400
    
    related = data_fetcher.get_related_topics(topic)
    return jsonify({
        "success": True,
        "topic": topic,
        "related_topics": related
    })


@api_bp.route('/sentiment', methods=['POST'])
def analyze_sentiment():
    """Analyze sentiment for a topic."""
    data = request.get_json(silent=True)
    if not data or 'topic' not in data:
        return jsonify({
            "success": False,
            "error": "Missing 'topic' field"
        }), 400
    
    topic = data['topic']
    
    # Fetch topic data
    data_result = data_fetcher.fetch_topic_data(topic)
    if not data_result.get('success', False):
        return jsonify({
            "success": False,
            "error": "Failed to fetch topic data"
        }), 500
    
    # Create topic data model
    from models.data_model import TopicData
    topic_data = TopicData(
        topic=topic,
        wikipedia=data_result['data']['wikipedia'],
        dbpedia=data_result['data']['dbpedia'],
        news=data_result['data']['news']
    )
    
    # Analyze sentiment
    sentiment_result = narrative_generator.analyze_sentiment(topic_data)
    
    if not sentiment_result.get('success', False):
        return jsonify({
            "success": False,
            "error": "Failed to analyze sentiment"
        }), 500
    
    return jsonify({
        "success": True,
        "topic": topic,
        "sentiment": sentiment_result['sentiment_analysis']
    })


@api_bp.route('/story', methods=['POST'])
def generate_story():
    """Generate a creative story for a topic."""
    data = request.get_json(silent=True)
    if not data or 'topic' not in data:
        return jsonify({
            "success": False,
            "error": "Missing 'topic' field"
        }), 400
    
    topic = data['topic']
    style = data.get('style', 'short story')
    genre = data.get('genre')
    
    # Fetch topic data
    data_result = data_fetcher.fetch_topic_data(topic)
    if not data_result.get('success', False):
        return jsonify({
            "success": False,
            "error": "Failed to fetch topic data"
        }), 500
    
    # Create topic data model
    from models.data_model import TopicData
    topic_data = TopicData(
        topic=topic,
        wikipedia=data_result['data']['wikipedia'],
        dbpedia=data_result['data']['dbpedia'],
        news=data_result['data']['news']
    )
    
    # Generate creative story
    story_result = narrative_generator.generate_creative_story(
        topic_data=topic_data,
        style=style,
        genre=genre
    )
    
    if not story_result.get('success', False):
        return jsonify({
            "success": False,
            "error": "Failed to generate story"
        }), 500
    
    return jsonify({
        "success": True,
        "topic": topic,
        "style": style,
        "genre": genre,
        "story": story_result['story']
    })


@api_bp.route('/health', methods=['GET'])
def health_check():
    """API health check endpoint with detailed status information."""
    # Get version information
    version = "1.0.0"
    
    # Check detailed API status
    api_status = get_all_api_statuses()
    
    # Create response
    response = {
        "status": api_status["overall_status"],
        "version": version,
        "apis": api_status["services"],
        "summary": api_status["summary"]
    }
    
    # Set status code based on overall status
    status_code = 200
    if api_status["overall_status"] == "degraded":
        status_code = 207  # Multi-Status
    elif api_status["overall_status"] == "incomplete":
        status_code = 424  # Failed Dependency
    elif api_status["overall_status"] == "down":
        status_code = 503  # Service Unavailable
    
    return jsonify(response), status_code


# Error handlers
@api_bp.errorhandler(Exception)
def handle_exception(e):
    """Handle all exceptions."""
    logger.exception(e)
    
    # If it's an HTTP exception, use its error code
    if isinstance(e, HTTPException):
        response = jsonify({
            "success": False,
            "error": e.description
        })
        response.status_code = e.code
        return response
    
    # Otherwise return a 500 error
    return jsonify({
        "success": False,
        "error": "Server error",
        "details": str(e)
    }), 500


def create_app():
    """Create and configure the Flask application."""
    app = Flask(__name__)
    
    # Apply configuration
    app.config['SECRET_KEY'] = FlaskConfig.SECRET_KEY
    app.config['DEBUG'] = FlaskConfig.DEBUG
    
    # Register blueprints
    app.register_blueprint(api_bp)
    app.register_blueprint(images_bp)
    
    # Root route
    @app.route('/')
    def index():
        """Render the main application page."""
        return render_template('index.html')
    
    @app.route('/about')
    def about():
        """Render the about page."""
        return render_template('about.html')
    
    @app.route('/status')
    def status():
        """Render the status page."""
        # Get API status information
        api_status = get_all_api_statuses()
        
        return render_template(
            'status.html',
            status=api_status["overall_status"],
            apis=api_status["services"],
            summary=api_status["summary"]
        )
    
    # Handle 404 errors
    @app.errorhandler(404)
    def not_found(e):
        if request.path.startswith('/api/'):
            # Return JSON for API routes
            return jsonify({
                "success": False,
                "error": "Endpoint not found"
            }), 404
        # Return HTML for other routes
        return render_template('404.html'), 404
    
    # Register global error handler
    @app.errorhandler(Exception)
    def handle_exception(e):
        """Handle all exceptions."""
        logger.exception(e)
        
        # If it's an HTTP exception, use its error code
        if isinstance(e, HTTPException):
            if request.path.startswith('/api/'):
                # Return JSON for API routes
                response = jsonify({
                    "success": False,
                    "error": e.description
                })
                response.status_code = e.code
                return response
            # Return HTML for other routes
            return render_template('error.html', error=e), e.code
        
        # Otherwise return a 500 error
        if request.path.startswith('/api/'):
            # Return JSON for API routes
            return jsonify({
                "success": False,
                "error": "Server error",
                "details": str(e)
            }), 500
        # Return HTML for other routes
        return render_template('error.html', error=e), 500
    
    return app


if __name__ == '__main__':
    flask_app = create_app()
    port = FlaskConfig.PORT
    flask_app.run(host='0.0.0.0', port=port)
