"""
API Status utility for monitoring the health of all external APIs
used in the CONTRA application.
"""

import os
import requests
from typing import Dict, List, Any
import logging

from config import APIConfig

logger = logging.getLogger(__name__)

def check_groq_api() -> Dict[str, Any]:
    """Check if Groq API key is configured and working."""
    result = {
        "name": "Groq LLaMA API",
        "status": "unknown",
        "message": ""
    }
    
    if not APIConfig.GROQ_API_KEY or APIConfig.GROQ_API_KEY == "dummy_key_replace_with_real_one":
        result["status"] = "missing"
        result["message"] = "API key not configured. Update GROQ_API_KEY in .env file."
        return result
    
    try:
        # Simple API health check to Groq
        headers = {
            "Authorization": f"Bearer {APIConfig.GROQ_API_KEY}",
            "Content-Type": "application/json"
        }
        response = requests.get(
            "https://api.groq.com/v1/models",
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 200:
            result["status"] = "ok"
            models = response.json().get("data", [])
            result["message"] = f"API connection successful. {len(models)} models available."
        else:
            result["status"] = "error"
            result["message"] = f"API error: {response.status_code} - {response.text}"
    
    except Exception as e:
        result["status"] = "error"
        result["message"] = f"Connection error: {str(e)}"
    
    return result

def check_stable_diffusion() -> Dict[str, Any]:
    """Check if Stable Diffusion endpoint is configured and working."""
    result = {
        "name": "Stable Diffusion API",
        "status": "unknown",
        "message": ""
    }
    
    if not APIConfig.SD_ENDPOINT:
        result["status"] = "missing"
        result["message"] = "Endpoint not configured. Update SD_GRADIO_ENDPOINT in .env file."
        return result
    
    try:
        # Check if service is responding
        response = requests.get(
            APIConfig.SD_ENDPOINT.split("/predict")[0],  # Base URL without /predict
            timeout=10
        )
        
        if response.status_code == 200:
            result["status"] = "ok"
            result["message"] = "API connection successful."
        else:
            result["status"] = "error"
            result["message"] = f"API error: {response.status_code}"
    
    except Exception as e:
        result["status"] = "error"
        result["message"] = f"Connection error: {str(e)}"
    
    return result

def check_news_api() -> Dict[str, Any]:
    """Check if News API key is configured and working."""
    result = {
        "name": "News API",
        "status": "unknown",
        "message": ""
    }
    
    if not APIConfig.NEWS_API_KEY or APIConfig.NEWS_API_KEY == "dummy_key_replace_with_real_one":
        result["status"] = "missing"
        result["message"] = "API key not configured. Update NEWS_API_KEY in .env file."
        return result
    
    try:
        # Test query to News API
        params = {
            'apiKey': APIConfig.NEWS_API_KEY,
            'q': 'test',
            'pageSize': 1
        }
        response = requests.get(
            "https://newsapi.org/v2/everything",
            params=params,
            timeout=10
        )
        
        if response.status_code == 200:
            result["status"] = "ok"
            result["message"] = "API connection successful."
        else:
            result["status"] = "error"
            error_msg = response.json().get("message", "Unknown error")
            result["message"] = f"API error: {error_msg}"
    
    except Exception as e:
        result["status"] = "error"
        result["message"] = f"Connection error: {str(e)}"
    
    return result

def get_all_api_statuses() -> Dict[str, Any]:
    """Get the status of all external APIs."""
    services = [
        check_groq_api(),
        check_stable_diffusion(),
        check_news_api()
    ]
    
    # Count services by status
    status_counts = {"ok": 0, "error": 0, "missing": 0, "unknown": 0}
    for service in services:
        status = service.get("status", "unknown")
        status_counts[status] = status_counts.get(status, 0) + 1
    
    # Determine overall status
    overall_status = "ok"
    if status_counts["error"] > 0:
        overall_status = "degraded"
    if status_counts["missing"] > 0:
        overall_status = "incomplete"
    if status_counts["ok"] == 0:
        overall_status = "down"
    
    return {
        "overall_status": overall_status,
        "services": services,
        "summary": {
            "total": len(services),
            "ok": status_counts["ok"],
            "error": status_counts["error"],
            "missing": status_counts["missing"],
            "unknown": status_counts["unknown"]
        }
    } 